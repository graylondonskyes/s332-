# Sovereign Author Publishing OS

## Command Position
A single author workspace should write once, package once, sell direct, and release outward from the same control plane.

## Why This Lives Inside SuperIDEv2
SuperIDEv2 now acts as the operator shell for author manufacturing, release proof, storefront launch prep, and outward channel packaging.

## Release Spine
- Canonical manuscript source
- Edition lineage
- Direct-sale storefront metadata
- SkyeBlog launch article seeded from the same release

## Launch Notes
The strongest lane is the owned direct-sale surface first. The outward channel package remains downstream from the canonical master.
